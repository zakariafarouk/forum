<!DOCTYPE html>
<html>
<head>
    <meta charset="UFT-8">
    <link rel="stylesheet" href="register.css">
    <title>register</title>
</head>

<body>
<?php
session_start();
include_once 'connexion.php';
$image=$_POST['username'].".".pathinfo($_FILES['file']['name'],PATHINFO_EXTENSION);
$username=$_POST['username'];
$password=$_POST['password'];
$register=$_POST['register'];
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$code=$_POST['code'];
if($register=="user" and $code=="0000" or $register=="admin" and $code=="1234"){
$x="INSERT INTO tt(firstname,lastname,password,username,image,register,code,etat) VALUES ('$firstname','$lastname','$password','$username','$image','$register','$code','0');";
$y=mysqli_query($connexion,$x);
if($y==1){
    move_uploaded_file($_FILES['file']['tmp_name'],"photo/".$image);
    echo "<center class=\"ti\">account created<br>";
    echo "<a href=\"index.php\">page d'accueil</a></center>";
}
else{
    echo "<center class=\"ti\">use another username<br>";
    echo "<a href=\"index.php\">page d'accueil</a></center>";
}}
else{
    echo "ereur dans le code"; 
}
?>
</body>