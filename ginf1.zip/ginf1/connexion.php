<?php
$dbservername="localhost";
$dbusername="root";
$dbpassword="";
$dbname="tt";
$connexion=mysqli_connect($dbservername,$dbusername,$dbpassword,$dbname);
?>