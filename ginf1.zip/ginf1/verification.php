<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF_8">
    <link rel="stylesheet" href="verification.css">
    <title>forum</title>
</head>
<body>
    <?php
    echo "<a href=\"deconnexion.php\">deconnexion</a> ";
    include_once 'connexion.php';
    if(isset($_POST['username'])and isset($_POST['password'])){
    $_SESSION['username']=$_POST['username'];
    $_SESSION['password']=$_POST['password'];
    abc:
    $x="SELECT username,password,etat,code FROM tt WHERE username='".$_SESSION['username']."'and password='".$_SESSION['password']."' ;";
    $y=mysqli_query($connexion,$x);
    $z=mysqli_num_rows($y);
            if($z==1){
            $a=mysqli_fetch_assoc($y);
            if($a['code']==1234){ 
            $requete = "SELECT * FROM tt";
            $result = mysqli_query($connexion,$requete);
            echo "<center><table border='1' ";
            echo "<tr>
            <td>firstname</td>
            <td>lastname</td>
            <td>username</td>
            <td>PHOTO</td>
            <td>reponse</td>
            </tr>";
            while($row= mysqli_fetch_assoc($result)){
            if($row['etat']=="0" and $row['code']!="1234"){
                echo "<tr>
                <form action=\"verification2.php\" method=\"POST\">
                <td>".$row['firstname']."</td>
                <td>".$row['lastname']."</td>
                <td>".$row['username']."</td>
                <td><img  alt=\"image\" src=\"./photo/".$row['image']."\" width=\"160\" height=\"160px\"></td>
                <td>
                <input class=\"aa\" type=\"submit\" name=\"accepter\" value=\"accepter\">
                <input type=\"hidden\" name=\"hidden\" value=".$row['id'].">
                <input class=\"aa\" type=\"submit\" name=\"refuser\" value=\"refuser\">
                </form>
                </td>
                </tr>";
            }
            }
            echo "</table></center>";
            }else{
             if($a['etat']==0){
             echo "<center class=\"ti\">tu doit attendre l'acceptation du admin</center>";
            }else{
             echo "<center><form class=\"far\" action=\"\" method=\"POST\">
             <input class=\"aa\" type=\"text\" name=\"text\">
             <input class=\"aa\" type=\"submit\" name=\"poser\" value=\"poser\"></form></center><br>";
             if(isset($_POST['poser'])){
                $text=$_POST['text'];
                $x="INSERT INTO question(idr,qr,text) VALUES ('a','q','$text');";
                $y=mysqli_query($connexion,$x);
            }
             $requete1 = "SELECT * FROM question WHERE qr='q';";
             $result1 = mysqli_query($connexion,$requete1);
             while($row1= mysqli_fetch_assoc($result1)){
             echo "<p class=\"rr\">&nbsp;&nbsp;".$row1['text']."</p>
                <p>
                <form action=\"verification1.php\" method=\"POST\">
                <input class=\"aa\" type=\"text\" name=\"text2\">
                <input type=\"hidden\" name=\"hidden\" value=".$row1['id'].">
                <input class=\"aa\" type=\"submit\" name=\"reponse\" value=\"reponse\">
                <input class=\"aa\" type=\"submit\" name=\"voire\" value=\"voire\">
                </form>
                </p>";
            }
            }
            }
    }else{
        unset($_SESSION['username']);
        unset($_SESSION['password']);
    }
    }else{
        if(isset($_SESSION['username']) and isset($_SESSION['password'])){
            goto abc;
        }
     }
    ?>
</body>
</html>