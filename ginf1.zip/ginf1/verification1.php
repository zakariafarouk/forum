<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF_8">
    <link rel="stylesheet" href="verification.css">
    <title>forum</title>
</head>
<body>
<?php
include_once 'connexion.php';
if(isset($_POST['reponse'])){
    $text2=$_POST['text2'];
    $id=$_POST['hidden'];
    $x="INSERT INTO question(idr,qr,text) VALUES ('$id','r','$text2');";
    $y=mysqli_query($connexion,$x); 
    unset($_POST['reponse']);
    header('Location: verification.php');
}
    $id=$_POST['hidden'];
    $requete2 = "SELECT * FROM question WHERE qr='r' and idr='".$id."';";
    $result2 = mysqli_query($connexion,$requete2);
    while($row2= mysqli_fetch_assoc($result2)){
        echo "<p class=\"yt\">".$row2['text']."</p><hr><br>";
    }
?>
</body>