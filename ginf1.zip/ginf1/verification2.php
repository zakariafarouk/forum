<?php
include_once 'connexion.php';
$requete = "SELECT * FROM tt";
$result = mysqli_query($connexion,$requete);
$row= mysqli_fetch_assoc($result);
$id=$_POST['hidden'];
if(isset($_POST['accepter'])){
   $x="UPDATE tt SET etat = '1' WHERE id='".$id."';";
   $z = mysqli_query($connexion,$x);
   unset($_POST['accepter']);
   header('Location: verification.php');
 }
 if(isset($_POST['refuser'])){
    $x="DELETE FROM tt WHERE id='".$id."';";
    $z = mysqli_query($connexion,$x);
    unset($_POST['refuser']);
    header('Location: verification.php');
 }
?>