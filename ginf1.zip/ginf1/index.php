<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="index1.css">
    <title>inscription</title>
</head>
<body>
    <center class="title"><p>Home Page</p></center>
    <form action="verification.php" method="POST">
    <center class="ti">
        <p><label>username</label>
        <input type="text" name="username"></p>
    </center>
    <center class="ti">
        <p><label>password</label>
        <input type="password" name="password"></p>
    </center>
    <div id="page">
        <input type="submit" name="submit" value="connexion">
     </form>
     <form action="register.php" method="POST">
        <input type="submit" name="submit" value="register">
    </div>
    </form>


