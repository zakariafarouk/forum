<!DOCTYPE html>
<html>
<head>
    <meta charset="UFT-8">
    <link rel="stylesheet" href="register.css">
    <title>formulaire</title>
</head>

<body>
<?php
echo "<a href=\"index.php\" > home page </a>
    <center><h1 class=\"title\"> formulaire </h1></center>
    <center><img src=\"user.png\" width=\"120\" height=\"120\" ></center>
    <form class=\"cc\" action=\"register1.php\" method=\"POST\" enctype=\"multipart/form-data\">
        <p><lable class=\"a\">image</lable>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type=\"file\"  name=\"file\"></p>
        <p><lable class=\"a\">username</lable>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input class=\"b\" type=\"text\"  name=\"username\"</p>
        <p><lable class=\"a\">firstname</lable>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input class=\"b\" type=\"text\"  name=\"firstname\"></p>
        <p><lable class=\"a\">lastname</lable>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input class=\"b\" type=\"text\"  name=\"lastname\"></p>
        <p><lable class=\"a\">password</lable>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input class=\"b\" type=\"password\"  name=\"password\"></p>

        
        </p><label class=\"a\">account:</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type=\"radio\" name=\"register\" value=\"user\">
        <label class=\"a\">user</label><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type=\"radio\" name=\"register\" value=\"admin\">
        <label class=\"a\">admin</label></p>
 
        <p><label class=\"a\">code</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input class=\"b\" type=\"text\" name=\"code\" value=\"0000\"></p>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input class=\"b\" type=\"submit\"  value=\"submit\">
    </form>
        ";
        
?>
</body>   
</html> 
